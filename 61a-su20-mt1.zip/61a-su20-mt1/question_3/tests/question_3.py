test = {'name': 'question_3',
 'points': 10,
 'suites': [{'cases': [{'code': '>>> falconer(1234, 1)\n'
                                '4\n'
                                '\n'
                                '>>> falconer(32749, 2)\n'
                                '79\n'
                                '\n'
                                '>>> falconer(1917, 2)\n'
                                '97\n'
                                '\n'
                                '>>> falconer(32749, 18)\n'
                                '32749\n'}],
             'scored': True,
             'setup': 'from question_3 import *',
             'type': 'doctest'}]}